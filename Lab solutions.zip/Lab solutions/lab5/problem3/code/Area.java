/**
 * 
 */

/**
 * @author Group 13
 *
 */
public interface Area {
	
	public double computeArea();

}
