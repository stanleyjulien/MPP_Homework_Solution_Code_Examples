package lesson5.labsolns.prob2;

public interface QuackBehavior {
	public void quack();
}
