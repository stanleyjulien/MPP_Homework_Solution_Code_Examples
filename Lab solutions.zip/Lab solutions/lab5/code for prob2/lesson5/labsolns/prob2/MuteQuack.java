package lesson5.labsolns.prob2;

public class MuteQuack implements QuackBehavior {
	public void quack() {
		System.out.println("  cannot quack");
	}
}
