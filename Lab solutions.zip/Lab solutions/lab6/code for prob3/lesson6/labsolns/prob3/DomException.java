package lesson6.labsolns.prob3;
public class DomException extends Exception {
	
	public DomException() {
		super();
	}
	
	public DomException(String s) {
		super(s);
	}

}

