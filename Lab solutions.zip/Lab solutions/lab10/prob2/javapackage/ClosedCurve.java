package lesson10.labsolns.prob2.javapackage;
import lesson10.labsolns.prob2.bugreporter.BugReport;

@BugReport(assignedTo="Tom Jones", severity=1, reportedBy="Corazza")
public interface ClosedCurve {
	public double computePerimeter();
}
