package lesson7.lecture.defaultmethodrules.intfacesupclass;

public class Implementer extends SupClass implements SupInt1 {
	//myMethod
	

	public static void main(String[] args) {
		Implementer i = new Implementer();
		i.myMethod(3);
	}
}
