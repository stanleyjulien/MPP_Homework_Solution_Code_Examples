package lesson7.labs.prob3_staticstorage;

public class Cache {
	//shouldn't be static
	public static long timeout() {
		//seconds
		return 1;
	}
}
