package lesson7.labs.prob3_staticstorage;

public enum StorageKey {
	LOGGED_IN;
}
