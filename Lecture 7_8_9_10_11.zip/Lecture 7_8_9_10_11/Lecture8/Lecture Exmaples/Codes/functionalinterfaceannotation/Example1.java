package lesson8.lecture.functionalinterfaceannotation;


public interface Example1 {
	String toString();
}


