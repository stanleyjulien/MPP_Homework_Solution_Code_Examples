package lesson10.lecture.tdd.UnitTestExample;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.sun.org.apache.xpath.internal.functions.Function;

public class myUnitTestcase {

	@Test
	public void test() {
		assertEquals("Hello testing","Hello testing");
	}
	
}
